# Data Encyption Standards (DES)

A readable and easy to understand implementation of the well known DES encryption algorithm.
