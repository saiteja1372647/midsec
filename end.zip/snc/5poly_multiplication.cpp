#include <bits/stdc++.h>
using namespace std;
void printBinary(int n)
{
	int k;
	for (int c = 7; c >= 0; c--)
	{
		k = n >> c;

		if (k & 1)
		printf("1");
		else
		printf("0");
	}

	printf("\n");
}
int main()
{
	//GF(2^8);
	int a = 0,b = 0;
	int n = 8;
	char ch;
	cout<<"Enter the Polynomial a(x)"<<endl;
	for(int i = n-1; i >= 0; i --)
	{
		cin>>ch;
		if(ch == '1')
		{
			a = a | (1 << i);
		}
	}

	cout<<"Enter the Polynomial b(x)"<<endl;
	int highest_deg;
	bool flag = true;
	for(int i = n-1; i >= 0; i --)
	{
		cin>>ch;
		if(ch == '1')
		{
			if(flag)
			highest_deg = i, flag = false;

			b = b | (1 << i);
		}
	}
	
	printBinary(a);
	printBinary(b);

	int c = a;
	int res = 0;

	if(b & 1) 
	res = a;

	for(int i = 1; i <= highest_deg; i++)
	{
		if(c & (1 << (n - 1)))
		{
			c = c << 1;
			c = c ^ 27;			// 27(10) = 00011011(2);
		}
		else
		{
			c = c << 1;
		}
		
		if(((1 << i) & b))
		{
			res = res ^ c;			
		}		
	}
	cout<<"Multiplication is "<<endl;
	printBinary(res);
}



