#include <stdio.h>
#include <gmp.h>
#include <time.h>

int main()
{

	mpz_t a,b,c,e,d,max,m;
	mpz_inits(a,b,c,d,e,max,m,NULL);
	gmp_randstate_t state;
	gmp_randinit_mt(state);
	unsigned long seed;
	seed  = time(NULL);
	gmp_randseed_ui(state,seed);
	mpz_set_ui(max,1000);
	mpz_urandomm(a,state,max);
	mpz_urandomm(b,state,max);                           // int bits =10; mpz_rrandomb(a,state,bits);		
	mpz_urandomm(m,state,max);	
	
	gmp_printf("The selected numbers are %Zd, %Zd in mod %Zd\n",a,b,m);
	
	mpz_mod(a,a,m);
	mpz_mod(b,b,m);
	mpz_add(c,a,b);
	mpz_sub(d,a,b);
	mpz_mul(e,a,b );
	mpz_mod(e,e,m);
	mpz_mod(c,c,m);
	mpz_mod(d,d,m);
	
	
	
	gmp_printf("\nsum modulo is %Zd \nsub modulo is %Zd \nmul modulo %Zd\n",c,d,e);
	
	
	
		
	return 0;
}

