#include <bits/stdc++.h>
using namespace std;
void printBinary(int n)
{
	int k;
	for (int c = 7; c >= 0; c--)
	{
		k = n >> c;

		if (k & 1)
		printf("1");
		else
		printf("0");
	}

	printf("\n");
}

int getMSB(int n)
{
	return log2(n);
}

int polydiv(int a, int b, int &quo, int &rem)
{

	int highest_deg_a = getMSB(a);
	int highest_deg_b = getMSB(b);
	quo = 0;

	while(highest_deg_a >= highest_deg_b)	//continue doing division
	{
		quo = quo | (1 << (highest_deg_a - highest_deg_b));
	
		//Multiplication of x^(highest_deg_a - highest_deg_b) and a
		int temp = b << (highest_deg_a - highest_deg_b);
		a = a ^ temp;


		highest_deg_a = getMSB(a);
		highest_deg_b = getMSB(b);
	}
	rem = a;
}

void polymul(int a, int b, int &res)
{
	int c = a;
	res = 0;

	if(b & 1) 
	res = a;
	
	int highest_deg = getMSB(b);
	int n = 8;

	for(int i = 1; i <= highest_deg; i++)
	{
		if(c & (1 << (n - 1)))
		{
			c = c << 1;
			c = c ^ 27;			// 27(10) = 00011011(2);
		}
		else
		{
			c = c << 1;
		}
		
		if(((1 << i) & b))
		{
			res = res ^ c;			
		}		
	}	
}

int main()
{
	//GF(2^8);
	int a = 0,b = 0;
	int n = 8;
	char ch;

	
	cout<<"Enter the modular Polynomial a(x)"<<endl;
	for(int i = 8; i >= 0; i --)
	{
		cin>>ch;
		if(ch == '1')
		{
			a = a | (1 << i);
		}
	}

	
	cout<<"Enter the Polynomial b(x)"<<endl;
	
	for(int i = n-1; i >= 0; i --)
	{
		cin>>ch;
		if(ch == '1')
		{
			b = b | (1 << i);
		}
	}
	
	int r1 = a, r2 = b;
	int q, r, s2 = 0, t2 = 1, s1 = 1, t1 = 0, s, t;

	while(r2 > 0)
	{
		polydiv(r1, r2, q, r);
		
		r1 = r2;
		r2 = r;

		int temp;
		//t = t1-qt2;t1= t2;t2= t;
		polymul(q, t2, temp);
		

		t = t1 ^ temp;
		t1 = t2;
		t2 = t;
		
	}

	cout<<"Modular Multiplicative inverse is  "<<endl;
	printBinary(t1);

	

	
}
