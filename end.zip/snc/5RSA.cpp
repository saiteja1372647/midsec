rsa.c  


#include <stdio.h>
#include <gmp.h>
 #include <time.h>

int main ()
{    
  
	mpz_t p,q,ph, p1, q1, r, e,d,b, g,n, m, pl,c;
	mpz_inits (p,q,ph,p1, q1,e,d,b,g,m,c, pl,NULL);
	mpz_inits(r, n, NULL);

  	gmp_randstate_t state;
	gmp_randinit_mt(state);
	unsigned long seed;
	seed = time(NULL);
	gmp_randseed_ui(state,seed);
	int bits = 1024;
	mpz_rrandomb(r,state,bits);                                                                    
	
	mpz_nextprime (p , r);
	mpz_nextprime (q , p);
	mpz_mul(n, p, q);

	mpz_set_ui (p1, 1 );
	mpz_set_ui (q1 , 1 );
	mpz_set_ui (e , 17 );
	mpz_set_ui (m , 89 );

	mpz_sub(p1,p,p1);
	mpz_sub(q1,q,q1);
	mpz_mul(ph,p1, q1);

  	mpz_gcdext ( g , d , b , e , ph );
	mpz_powm (c, m, e, n);
	mpz_powm (pl, c, d, n);



	gmp_printf("Two primes are ===  \n");
	gmp_printf("p == %Zd \nq ==  %Zd\n",p, q);
	gmp_printf("p-1 ==  %Zd \nq-1 == %Zd\n",p1, q1);
	gmp_printf("ph == %Zd \n ",ph);
	gmp_printf("e == %Zd \n ", e);
	gmp_printf("d == %Zd \n ", d);
	gmp_printf("Cipher Text  == %Zd \n ", c); 
	gmp_printf("Plain Text  == %Zd \n ", pl);



}



