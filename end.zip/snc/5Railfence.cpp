rail fence


#include<bits/stdc++.h>
#include<string.h>
using namespace std;
int main()
{
string s;
string s1="";
string s2="";
cin>>s;
for(int i=0;i<s.length();i++)
{
if(i%2==0)
s1=s1+s[i];
else
s2=s2+s[i];
}
s=s1+s2;
cout<<"transposition cipher text encryption :"<<s<<endl;
s1="";
s2="";
int n=s.length();
int m=n;
int i=0;
s1=s.substr(0,(n+1)/2);
s2=s.substr((n+1)/2,(n-1)/2);
s="";
int j=0,k=0;
for(i=0;i<m;i++)
{
if(i%2==0)
s=s+s1[j++];
else
s=s+s2[k++];
}
cout<<"transposition cipher text decryption :"<<s<<endl;


}


