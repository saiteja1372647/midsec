gcd.c


#include <stdio.h>
#include <gmp.h>
 #include <time.h>

int main ()
{    
  
	mpz_t a, b, x, y, q, r, r1, r2, s, s1, s2, t, t1, t2;
	mpz_inits (a, b, x, y, q, r, r1, r2, s, s1, s2, t, t1, t2, NULL);

	
	gmp_scanf ("%Zd", a);
	gmp_scanf ("%Zd", b);

	if(mpz_cmp(a, b) < 0)
	{
		mpz_swap(a ,b);
	}	

	mpz_set(r1, a);
	mpz_set(r2, b);
	mpz_set_ui(s1, 1);
	mpz_set_ui(t1, 0);
	mpz_set_ui(s2, 0);
	mpz_set_ui(t2, 1);
	

	while(mpz_cmp_ui(r2, 0) > 0)
	{
		mpz_fdiv_q(q, r1, r2);

		mpz_mod(r, r1, r2);

		mpz_set(r1, r2);
		mpz_set(r2, r);

		mpz_mul(s, q, s2);
		mpz_sub(s, s1, s);

		mpz_set(s1, s2);
		mpz_set(s2, s);

		mpz_mul(t, q, t2);
		mpz_sub(t, t1, t);

		mpz_set(t1, t2);
		mpz_set(t2, t);
	}

	gmp_printf("GCD is %Zd \n s is %Zd \n t  is %Zd \n ", r1, s1, t1);
}




