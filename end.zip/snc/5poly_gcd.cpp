polygcd

#include <bits/stdc++.h>
using namespace std;
void printBinary(int n)
{
	int k;
	for (int c = 7; c >= 0; c--)
	{
		k = n >> c;

		if (k & 1)
		printf("1");
		else
		printf("0");
	}

	printf("\n");
}

int getMSB(int n)
{
	return log2(n);
}

int polydiv(int a, int b, int &quo, int &rem)
{

	int highest_deg_a = getMSB(a);
	int highest_deg_b = getMSB(b);
	quo = 0;
//	cout<<highest_deg_a<<"::"<<highest_deg_b<<endl;

	while(highest_deg_a >= highest_deg_b)	//continue doing division
	{
		quo = quo | (1 << (highest_deg_a - highest_deg_b));
	
		//Multiplication of x^(highest_deg_a - highest_deg_b) and a
		int temp = b << (highest_deg_a - highest_deg_b);
		a = a ^ temp;


		highest_deg_a = getMSB(a);
		highest_deg_b = getMSB(b);
	}

//	cout<<"Quotient is "<<endl;
//	printBinary(quo);

//	cout<<"Remainder is "<<endl;
//	printBinary(a);
	rem = a;
}

int main()
{
	//GF(2^8);
	int a = 0,b = 0;
	int n = 8;
	char ch;

	
	cout<<"Enter the Polynomial a(x)"<<endl;
	for(int i = n-1; i >= 0; i --)
	{
		cin>>ch;
		if(ch == '1')
		{
			a = a | (1 << i);
		}
	}

	
	cout<<"Enter the Polynomial b(x)"<<endl;
	
	for(int i = n-1; i >= 0; i --)
	{
		cin>>ch;
		if(ch == '1')
		{
			b = b | (1 << i);
		}
	}
	
	int r1 = a, int r2 = b;

	while(r2 > 0)
	{
		polydiv(r1, r2, q, r);
		
		cout<<"Quotient is ";
		printBinary(q);

		cout<<"Remainder is ";
		printBinary(r);

		r1 = r2;
		r2 = r;
	}

	cout<<"GCD is "endl;
	printBinary(r1);

	
}

