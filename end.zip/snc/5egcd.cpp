egcd.c 


#include <stdio.h>
#include <gmp.h>

int main(){

	mpz_t number1,number2,coef1,coef2,tempquotient,tempx1,tempy2,tempx2,tempy1,remainder,temp1,temp2;
	mpz_inits(number1,number2,coef1,coef2,tempquotient,tempx1,tempy1,tempx2,tempy2,remainder,temp1,temp2,NULL);
	mpz_set_ui(tempx1,1);
	mpz_set_ui(tempx2,0);
	mpz_set_ui(tempy1,0);
	mpz_set_ui(tempy2,1);
	mpz_set_ui(remainder,1);
				
	
	gmp_randstate_t state;
	gmp_randinit_mt(state);
	unsigned long seed;
	seed  = time(NULL);
	gmp_randseed_ui(state,seed);
	mpz_set_ui(max,1000);
	mpz_rrandomm(number1,state,max);
	mpz_rrandomm(number2,state,max);                           // int bits =10; mpz_rrandomb(a,state,bits);			
	
	gmp_printf(" The numbers are %Zd",number1);
	gmp_printf(" and %Zd\n",number2);
	
	if(mpz_cmp(number1,number2) < 0)mpz_swap(number1,number2);
	
	while(mpz_cmp_ui(remainder,0) > 0){
	
		/* normal euclid gcd algoritm */
		mpz_div(tempquotient,number1,number2);
		mpz_mod(remainder,number1,number2);
		mpz_set(number1,number2);
		mpz_set(number2,remainder);
		
		/* extended */
		mpz_set(temp1,tempx1);
		mpz_mul(temp2,tempquotient,tempx2);
		mpz_sub(temp1,temp1,temp2);
		mpz_set(tempx1,tempx2);
		mpz_set(tempx2,temp1);
		
		mpz_set(temp1,tempy1);
		mpz_mul(temp2,tempquotient,tempy2);
		mpz_sub(temp1,temp1,temp2);
		mpz_set(tempy1,tempy2);
		mpz_set(tempy2,temp1);
		
	}
	
	

	gmp_printf("\n%Zd %Zd \n" ,tempx1,tempy1);
	return 0;
}


/*

	testcases: 240,46 -> -9 ,47
			   35,15  -> 1,-2
			   1,1 -> 0,1
			   */


