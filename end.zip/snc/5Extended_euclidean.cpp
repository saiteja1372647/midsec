extended euclidean.c


/*
	gmp_randstate_t state;
	gmp_randinit_mt(state);
	unsigned long seed;
	seed = time(NULL);

		mpz_set_ui(max,100000);
		mpz_urandomm(a,state,max);

	//the following method is preferable*/


#include <stdio.h>
#include <gmp.h>
#include <time.h>

void exeuclid(mpz_t a,mpz_t b,mpz_t x,mpz_t y,mpz_t d)
{
	//gmp_printf("euclid called\n");
	mpz_t x1,x2,y1,y2,q,r;
	mpz_inits(x1,x2,y1,y2,q,r,NULL);
		mpz_set_ui(x2,1);
		mpz_set_ui(y1,1);
		while(mpz_cmp_ui(b,0) > 0)
		{
			mpz_fdiv_q(q,a,b); 
			mpz_set(r,a); //r = a
			mpz_submul(r,q,b); // r = a- qb
			mpz_set(x,x2); //x = x2
			mpz_submul(x,q,x1); // x = x2 - qx1
			mpz_set(y,y2);
			mpz_submul(y,q,y1);
			mpz_set(a,b);
			mpz_set(b,r);
			mpz_set(x2,x1);
			mpz_set(x1,x);
			mpz_set(y2,y1);
			mpz_set(y1,y);
		}
		mpz_set(d,a);
		mpz_set(x,x2);
		mpz_set(y,y2);
	
}
void main()
{
	mpz_t a,b,d,x,y;
	mpz_inits(a,b,d,x,y,NULL);
	
	gmp_randstate_t state;
	gmp_randinit_mt(state);
	unsigned long seed;
	seed = time(NULL);
	gmp_randseed_ui(state,seed);
	/*
		mpz_set_ui(max,100000);
		mpz_urandomm(a,state,max);*/

	//the following method is preferable
	int bits = 16;
	mpz_rrandomb(a,state,bits);                                                                    
	mpz_rrandomb(b,state,bits);
	if(mpz_cmp_ui(b,0) == 0)
	{//gmp_printf("777777777777777\n");
			mpz_set(d,a);
			mpz_set_ui(x,1);
			mpz_set_ui(y,0);
			gmp_printf("%Zd = %Zd*%Zd + %Zd*%Zd",d,a,x,b,y);
	}
	else
	{//gmp_printf("Else");
	mpz_t a1,b1;
		mpz_init_set(a1,a);
		mpz_init_set(b1,b);
		exeuclid(a1,b1,x,y,d);
		gmp_printf("%Zd = (%Zd)*(%Zd) + (%Zd)*(%Zd)\n",d,a,x,b,y);
	}

}



