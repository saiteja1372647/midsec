
ceasar

#include <bits/stdc++.h>
using namespace std;
void cipher(string &a,int k){
	for(int i = 0;i < a.length();i++)
	{	
		a[i] = ((a[i] + k - 'a')%26) + 'a';
	}
}

void decipher(string &a,int k){
	for(int i = 0;i < a.length();i++)
	{	
		a[i] = (a[i] - k - 'a' + 26)%26 + 'a';
	}
}

int main()
{
	int k;
	cout<<"Enter the key"<<endl;
	cin>>k;
	string a;
	cin>>a;
	cipher(a,k);
	cout<<"cipher text is "<<a<<endl;
	decipher(a,k);
	cout<<"deciphered text is "<<a<<endl;
	return 0;
}

