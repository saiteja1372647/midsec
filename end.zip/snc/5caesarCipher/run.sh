g++ caesarCipher.cpp -o caesarcipher
./caesarcipher <input.txt> output.txt