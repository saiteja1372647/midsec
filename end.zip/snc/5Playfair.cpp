playfair


#include <bits/stdc++.h>
using namespace std;
vector<int> find(char lookup[5][5],char c)
{
	vector<int> res;
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			if(lookup[i][j] == c)
			{
				res.push_back(i);
				res.push_back(j);
				return res;
			}
		}
	}
}
void cipher(char lookup[5][5],string &a)
{
	string temp = "";
	for(int i = 0;i < a.length();i = i + 1)
	{
		if(i + 1 < a.length())
		{
			if( a[i] == a[i+1])
			{
				temp = temp  + a[i] + 'x';
			}
			else if(a[i] != a[i+1])
			{
				temp = temp + a[i] + a[i+1];
				i++;
			}
		}
	}
	if(temp.length() %2 == 1) temp += 'x';
	cout<<temp<<"-------------------\n";int i,j,m,n;vector<int> ve;
	for(int k = 0; k < temp.length();k = k+2)
	{
		ve = find(lookup,a[k]);
		i = ve[0];
		j = ve[1];
		ve = find(lookup,a[k+1]);
		m = ve[0];
		n = ve[1];
		if(i == m)
		{ j = (j+1)%5;
			n = (n+1)%5;
		}
		if( j == n)
		{
			i = (i+1)%5;
			m = (m+1)%5;
		}
		cout<<lookup[m][j]<<lookup[i][n];
	}
	cout<<endl;
	
}

void decipher(string &a){
	cout<<a<<endl;
}

void fillup(char a[5][5],string key){
	int x = 0,y = 0;
	set <char> m;
	m.clear();
	for(int i = 0;i<key.length();i++){
		if(m.find(key[i]) != m.end())continue;
		if(key[i] == 'j' && m.find('i') != m.end())continue;
		else if(key[i] == 'j')
		{
			 key[i] = 'i';
		}
		m.insert(key[i]);
		a[x][y] = key[i];
		y++;
		if(y == 5){
			y = 0;
			x++;
		}
	}
	
	char b = 'a';
	bool flag = false;
	while(1){
		if(flag) break;
		for(int i = 0;i < 26;i++)
		{
			
			if(key.find(b + i) == string::npos)
			{
				a[x][y] = b+i;
				y++;
				if(y == 5)
				{
					y = 0;
					x++;
					if(x == 5)
					{
						flag = true;
						 break;
						 
						 }
				}
		
			}
			if(b + i == 'i') i++;
		}		
	}
}
int main()
{
	char a[5][5];
	string key,b;
	cin>>key;
	fillup(a,key);
	cout<<"Enter plain text"<<endl;
	cin>>b;
	string store;
	store = b;
	cipher(a,b);
	decipher(store);
	return 0;
}


